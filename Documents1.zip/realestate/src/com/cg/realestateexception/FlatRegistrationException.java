package com.cg.realestateexception;

public class FlatRegistrationException extends Exception{

}
