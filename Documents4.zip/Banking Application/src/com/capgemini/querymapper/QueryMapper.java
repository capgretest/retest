package com.capgemini.querymapper;

public class QueryMapper {
	public static final String SEARCHQUERY="select TRANSACTION_ID,CUSTOMER_NAME,IN_FAVOUR_OF,PHONE_NUMBER,sysdate,DD_AMOUNT,DD_COMMISSION,DD_DESCRIPTION from demand_draft where transaction_id=?";
}
