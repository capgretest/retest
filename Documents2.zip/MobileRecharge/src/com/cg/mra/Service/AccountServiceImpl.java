package com.cg.mra.Service;

import com.cg.mra.Dao.AccountDao;
import com.cg.mra.Dao.AccountDaoImpl;
import com.cg.mra.Exception.mobileRechargeException;
import com.cg.mra.beans.Account;


public class AccountServiceImpl implements AccountService {
	
	AccountDao dao = new AccountDaoImpl();



	 @Override

	 public Account getAccountDetails(String accountId) throws mobileRechargeException {

	 return dao.getAccountDetails(accountId);

	 }



	 @Override

	 public int rechargeAccount(String accountId, double rechargeAmount) throws mobileRechargeException {

	 return dao.rechargeAccount(accountId, rechargeAmount);

	 }



	 @Override

	 public boolean validateAccountId(String accountId) {

	 if (Integer.parseInt(accountId) > 0) {

	  return true;

	 }

	 return false;

	 }



	 @Override

	 public boolean validateAmount(double rechargeAmount) {

	 if (rechargeAmount > 0)

	  return true;

	 return false;

	 }



}
