package com.cg.mra.Service;

import com.cg.mra.Exception.mobileRechargeException;
import com.cg.mra.beans.Account;



public interface AccountService {

	 Account getAccountDetails(String accountId) throws mobileRechargeException;



	 int rechargeAccount(String accountId,double rechargeAmount) throws mobileRechargeException;



	 boolean validateAccountId(String accountId);



	 boolean validateAmount(double rechargeAmount);


}
