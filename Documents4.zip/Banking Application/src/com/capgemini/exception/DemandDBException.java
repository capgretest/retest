package com.capgemini.exception;

public class DemandDBException extends Exception {
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public DemandDBException(String message){
			super(message);
		}
}
