package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.FlatRegistrationService.FlatRegistrationServiceImpl;
import com.cg.beans.FlatRegistration;
import com.cg.realestateexception.FlatRegistrationException;



public class MainClient {
public static void main(String[] args) {

	FlatRegistrationServiceImpl frs=new FlatRegistrationServiceImpl();
	Scanner sc = new Scanner(System.in);
	do {
		System.out.println("1. Register Flat");
		System.out.println("2. Exit");
		String choice = sc.nextLine();
		switch (choice) {
		case "1":
	
	
			List<FlatRegistration>flist=frs.getAllOwnerId();
			if(flist.size()==0)

				System.out.println("No Owners Are Available");
			else{
				System.out.println("Existing owners Id's are :");
				for(FlatRegistration f:flist)

					System.out.println(f);
			}
	
			System.out.println("Select Owner Id from above list");
			String ownerId = sc.nextLine();
			System.out.println("Select Flat Type(1-1BHK, 2-2BHK)");
			String flatType = sc.nextLine();
			System.out.println("Enter flat area in square feet:");
			String flatArea = sc.nextLine();
			System.out.println("Enter Desired Rent Amount");
			String rentAmount = sc.nextLine();
			System.out.println("Enter Desired Deposit Amount");
			String depositAmount = sc.nextLine();
			FlatRegistration fs=new FlatRegistration(ownerId,flatType,flatArea,rentAmount,depositAmount);
			try {

				
					frs.registerFlat(fs);

				System.out.println("Flat Succesfully Registered :" + frs.getFlatRegNo());

			}
			catch (FlatRegistrationException e) {
				System.err.println(e.getMessage());
			}
		break;
			
			
			
	
}
}
