package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService {
		int addDemandDraftDetails(DemandDraft demandDraft) throws Exception;
		DemandDraft getDemandDraftDetails(int transactionId);
		public double ddcmo(double amount);
}
