package com.cg.cp.Exception;

public class PlayerException extends Exception {

	public PlayerException() {
		// TODO Auto-generated constructor stub
	}

	public PlayerException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PlayerException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PlayerException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public PlayerException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
