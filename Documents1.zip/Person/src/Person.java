
public class Person {
private	String Firstname;
private	String Lastname;
private	char Gender;
private int phone;
public Person()
{
}

	public Person(String Firstname,	String Lastname,char Gender)
	{
		this.Firstname=firstname;
		this.Lastname=lastname;
		this.Gender=gender;
	}
	public void setphone(int phone)
	{
		this.phone=phone;
	}
	
public getFirstname()	
	return
}
}
