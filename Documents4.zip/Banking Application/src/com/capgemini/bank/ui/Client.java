package com.capgemini.bank.ui;

//import java.sql.Date;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
/***
 * 
 * @author SHIVAREDDY
 * main method for operation working
 *
 */
public class Client {
public static void main(String[] args) {
	do{System.out.println("--------------- XYZ Bank Application-----------------------");
	System.out.println("1) Enter Demand Draft Details");
	System.out.println("2)Print Demand Draft");
	System.out.println("3)Exit");
	int option;
	IDemandDraftService dser=new DemandDraftService();
	@SuppressWarnings("resource")
	Scanner sc=new Scanner(System.in);
	option=sc.nextInt();
	switch (option) {
	case 1:
		System.out.println("Enter the customer number");
		String  cust=sc.next();
		System.out.println("Enter the in_favor_of");
		String favor=sc.next();
		System.out.println("Enter the phone Number");
		String phone=sc.next();
		System.out.println("Enter the dd amount");
		double amount=sc.nextDouble();
		double ddcom=dser.ddcmo(amount);
		System.out.println("Enter the dd Description");
		String desc=sc.next();
		DemandDraft demandDraft=new DemandDraft(0,cust,favor,phone, amount,ddcom,desc);
		try {
			dser.addDemandDraftDetails(demandDraft);
			System.out.println("your Demand Drad request has been successfully registered along with the:"+demandDraft.getTransaction_id());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		break;
case 2:
	System.out.println("Enter the transactioID to get details");
	int transactionId=sc.nextInt();
	DemandDraft draft=dser.getDemandDraftDetails(transactionId);
	draft.Display();
	break;
case 3:
	System.out.println("LogOut");
	System.exit(0);
	break;

	default:
		System.out.println("You have entered other than the option.");
		break;
	}
}while(true);
}
}
