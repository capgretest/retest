/************************************************************************************
 * File                 : EnquiryDBException.java
 * Author Name          : Ashish Dhar
 * Desc                 : User defined exception for enquiry database exceptions
 * Version              : 1.0
 * Last Modified Date   : 02-May-2019
 ************************************************************************************/
package com.cg.enquiry.exception;

public class EnquiryDBException extends Exception {

	public EnquiryDBException() {
		// TODO Auto-generated constructor stub
	}

	public EnquiryDBException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EnquiryDBException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EnquiryDBException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EnquiryDBException(String arg0, Throwable arg1, boolean arg2,
			boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
