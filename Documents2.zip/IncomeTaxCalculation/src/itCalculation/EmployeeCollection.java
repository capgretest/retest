package itCalculation;

import java.util.*;

public class EmployeeCollection {

	static Scanner sc = new Scanner(System.in);
	private static int f = 1;
	private  static ArrayList<EmployeeDetails> ed=new ArrayList<EmployeeDetails>();;
	static
	{
		EmployeeDetails e1 = new EmployeeDetails(101,"Suresh","ATGFH12345",33350.00);
		EmployeeDetails e2 = new EmployeeDetails(102,"Mahesh","POKUH28843",150200.00);
		EmployeeDetails e3 = new EmployeeDetails(103,"Deepak","ROPET56723",830000.00);
		EmployeeDetails e4 = new EmployeeDetails(104,"Pradeep","QWVGT98561",1000350.00);
		EmployeeDetails e5 = new EmployeeDetails(105,"Ankita","JUOLP761632",1950000.00);

		ed.add(e1);
		ed.add(e2);
		ed.add(e3);	
		ed.add(e4);
		ed.add(e5);
		
	}
	

	
		public static void addEmployeeDetails(EmployeeDetails emp) 
		{			
			ed.add(emp);
			System.out.println("Employee Details are added successfully");
		}



		public static ArrayList<EmployeeDetails> getEd() {
			return ed;
		}



		public static void setEd(ArrayList<EmployeeDetails> ed) {
			EmployeeCollection.ed = ed;
		}
		
		public static void calculate()
		{
			while(f==1)
			{
				System.out.println("\n 1. Calculate Income Tax \n 2. Display Employee Details \n");
				int choice = sc.nextInt();
				switch(choice)
				{
				case 1 : calcIncomeTax(); break;
				case 2 : displayEmployeeDetails(); break;
				default : System.exit(0);
				}
		
					
			}
		}
		
		/******************** Calculating Income Tax *****************/
		
		public static void calcIncomeTax()
		{
			f=0;
			System.out.println("\n Income Range \t \t \t \t Income Tax Rate \n"
					+ "Upto Rs. 2,50,000 \t \t \t Nil \n"
					+ "Rs. 2,50,000  to Rs. 5,00,000 \t \t 10% \n"
					+ "Rs. 5,00,000  to Rs. 10,00,000 \t \t 20% \n"
					+ "Above Rs. 10,00,000 \t \t \t 30% \n");
			
			System.out.println("\n Enter your Income \n");
			double in = sc.nextDouble();
			double itamount=0;
			if( in <= 250000)
			{ 
				itamount = 0;
				System.out.println("Payable Income Tax Amount = " + itamount + "\n");
			}
			else if( in > 250000 && in <= 500000)
			{ 
				itamount = (in * 10)/100;
				System.out.println("Payable Income Tax Amount = " + itamount + "\n");
			}
			else if( in > 500000 && in <= 100000)
			{ 
				itamount = (in * 20)/100;
				System.out.println("Payable Income Tax Amount = " + itamount + "\n");
			}
			else 
			{ 
				itamount = (in * 30)/100;
				System.out.println("Payable Income Tax Amount = " + itamount + "\n");
			}
		}
		
		/****************** Display Employee Details *********************/
		
		public static  void displayEmployeeDetails()
		{

			for(EmployeeDetails e : ed)
			{
				System.out.println(e + "\n");
			}
			f=0;
		}

	
		
		

}
