package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.exception.DemandDBException;

public interface IDemandDraftDAO {
		int addDemandDraftDetails(DemandDraft demanDraft)throws DemandDBException;
		DemandDraft getDemandDraftDetails(int transactionId);
}