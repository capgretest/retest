package com.cg.pms.Exception;

public class PurchaseException extends Exception {
	public PurchaseException(){
		
	}
	public PurchaseException(String str){
		super(str);
	}

}
