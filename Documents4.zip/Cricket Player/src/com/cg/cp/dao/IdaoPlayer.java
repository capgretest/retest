package com.cg.cp.dao;

import java.util.List;

import com.cg.cp.Exception.PlayerException;
import com.cg.cp.bean.PlayerBean;

public interface IdaoPlayer {

	String addNewPlayer(PlayerBean player) throws PlayerException;

	List<PlayerBean> getAllplayers() throws PlayerException;

	PlayerBean getPlayerDetailbyId(int id) throws PlayerException;

}
