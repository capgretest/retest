package com.cg.mra.Dao;

import com.cg.mra.Exception.mobileRechargeException;
import com.cg.mra.beans.Account;


public interface AccountDao {

	Account getAccountDetails(String accountId) throws mobileRechargeException;



	int rechargeAccount(String accountId, double rechargeAmount) throws mobileRechargeException;



	int rechargeAccount(String accountId, String string)
			throws mobileRechargeException;


}
