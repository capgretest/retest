package com.cg.mra.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mra.Exception.mobileRechargeException;
import com.cg.mra.beans.Account;
import com.cg.mra.util.Util;




public class AccountDaoImpl implements AccountDao {

	Connection conn;
	Logger logger=Logger.getRootLogger();
	
  public AccountDaoImpl() {
	 
	  
	  PropertyConfigurator.configure("Resource/log4j.properties");
		
     }


  
  /*******************************************************************************************************
	 - Return Type		:	 string
	 - Throws			:  	 mobileRechargeException
	 - Author			:	vinay kumar
	 - Creation Date	:	18/05/2019
	 - Description		:    getAccount details
	 ********************************************************************************************************/

	@Override

	public Account getAccountDetails(String accountId) throws mobileRechargeException {

		String sql = "Select * from Account where account_id=?";
		conn = Util.getConnection();
		Account account =null;

		try {

			PreparedStatement statement = conn.prepareStatement(sql);

			statement.setString(1, accountId);

			ResultSet query = statement.executeQuery();

			while (query.next()) {

				account = new Account();

				account.setAccountId(accountId);

				account.setAccountType(query.getString(2));

				account.setCustomerName(query.getString(3));

				account.setAccountBalance(query.getDouble(4));

			}

		} catch (SQLException e) {
			logger.error(e.getMessage());


		}

		if (account == null) {

			throw new mobileRechargeException("Entered Account Id does not Exist");

		}

		return account;

	}

	/*******************************************************************************************************
	 
	 - Return Type		:	double type
	 - Throws			:  	mobileRechargeException
	 - Author			:	Vinay kumar
	 - Creation Date	:	18/05/2019
	 - Description		:	For rechargeAccount()
	 ********************************************************************************************************/

	public int rechargeAccount(String accountId, String string) throws mobileRechargeException{

		String sql = "Select * from Account where account_id=?";
		conn = Util.getConnection();
		double acc_balance = 0;

		Account account = null;

		try {

			PreparedStatement statement = conn.prepareStatement(sql);

			statement.setString(1, accountId);

			ResultSet query = statement.executeQuery();

			while (query.next()) {

				account = new Account();

				account.setAccountId(accountId);

				account.setAccountType(query.getString(2));

				account.setCustomerName(query.getString(3));

				account.setAccountBalance(query.getDouble(4));

				acc_balance = query.getDouble(4);

			}

		} catch (SQLException e) {

			logger.error(e.getMessage());


		}

		if (account == null) {

			throw new mobileRechargeException("Can't recharge account as given account id doesn't exist");

		}

		String new_balance = acc_balance + string;

		String sql1 = "update Account set acc_balance=? where account_id=?";

		try {

			PreparedStatement statement = conn.prepareStatement(sql1);

			statement.setDate(1, new_balance);

			statement.setString(2, accountId);

			statement.executeUpdate();

		} catch (SQLException e) {

			logger.error(e.getMessage());

		}

		return 0;

	}



	@Override
	public int rechargeAccount(String accountId, double rechargeAmount)
			throws mobileRechargeException {
		// TODO Auto-generated method stub
		return 0;
	}



}



