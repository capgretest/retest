package com.capgemini.doctors.service;

import java.util.List;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exception.AppointmentException;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	IDoctorAppointmentDao rdao = new DoctorAppointmentDao();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
			throws AppointmentException {
		
		return rdao.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public List<DoctorAppointment> getDoctorAppointmentDetails(int appointmentId)
			throws AppointmentException {

		return rdao.getAppointmentDetails(appointmentId);
	}

}
