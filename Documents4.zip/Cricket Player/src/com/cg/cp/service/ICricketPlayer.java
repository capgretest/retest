package com.cg.cp.service;

import java.util.List;

import com.cg.cp.Exception.PlayerException;
import com.cg.cp.bean.PlayerBean;

public interface ICricketPlayer {

	String addNewPlayer(PlayerBean player) throws PlayerException;

	boolean isValidNewPlayer(PlayerBean player) throws PlayerException;

	List<PlayerBean> getAllplayers() throws PlayerException;

	PlayerBean getPlayerDetailbyId(int id) throws PlayerException;

}
