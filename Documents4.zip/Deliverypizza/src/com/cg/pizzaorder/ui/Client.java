package com.cg.pizzaorder.ui;

import java.util.Scanner;


import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.service.CustomerValidator;

public class Client{
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	do{
		System.out.println("1.place order");
		System.out.println("2. Display order");
		System.out.println("3. Exit.");
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			System.out.println("Enter Name of customer");
			String pname=sc.next();
			System.out.println("Enter address");
			String address=sc.next();
			System.out.println("Enter customer phNo");
			String phone = sc.nextLine();
			Customer customer=new Customer();
		}


}
}