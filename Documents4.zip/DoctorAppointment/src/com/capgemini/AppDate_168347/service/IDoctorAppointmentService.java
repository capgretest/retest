package com.capgemini.doctors.service;

import java.util.List;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.AppointmentException;

public interface IDoctorAppointmentService {

	int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws AppointmentException;
	List<DoctorAppointment> getDoctorAppointmentDetails(int appointmentId) throws AppointmentException;
}
