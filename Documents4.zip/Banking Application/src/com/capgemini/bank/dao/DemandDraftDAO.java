package com.capgemini.bank.dao;

import java.sql.Connection;
//import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.exception.DemandDBException;
import com.capgemini.querymapper.QueryMapper;
import com.capgemini.util.DBUtil;
/****
 * 
 * @author Nirmit
 * generate TransactionId(); is used to generate id automatically
 * addDemandDraftdetails is used to add detail in the sql
 * getDemandDraft is used to retrive the details
 *
 */
public class DemandDraftDAO implements IDemandDraftDAO{
	
	Connection con;
	public int generateTransactionId() throws DemandDBException{
		int generateTransactionId=0;
		String SQ="select trans_seq.nextval from dual";
		con=DBUtil.getConnection();
		try {
			Statement statement=con.createStatement();
			ResultSet resultSet=statement.executeQuery(SQ);
			resultSet.next();
			generateTransactionId=resultSet.getInt(1);
		} catch (SQLException e) {
			System.out.println("Problem accoured while generating Transaction ID"+e.getMessage());
		}
		return generateTransactionId;
	}
	
	
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws DemandDBException{
	String sql="INSERT INTO demand_draft values(?,?,?,?,sysdate,?,?,?)";
	demandDraft.setTransaction_id(generateTransactionId());
	
	con =DBUtil.getConnection();
	try{
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, demandDraft.getTransaction_id());
		pst.setString(2, demandDraft.getCustomer_name());
		pst.setString(3, demandDraft.getIn_favor_of());
		pst.setString(4, demandDraft.getPhone_number());
		pst.setDouble(5, demandDraft.getDd_amount());
		pst.setDouble(6, demandDraft.getDd_commission());
		pst.setString(7, demandDraft.getDd_description());
		pst.executeUpdate();
	}catch(SQLException e){
		throw new DemandDBException("Problem in inserting order details"+e);
	}
		return demandDraft.getTransaction_id();
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		con=DBUtil.getConnection();
		DemandDraft demandDraft=new DemandDraft();
		try {
			PreparedStatement preparedStatement = con.prepareStatement(QueryMapper.SEARCHQUERY);
			preparedStatement.setLong(1, transactionId);
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				demandDraft.setTransaction_id(resultSet.getInt(1));
				demandDraft.setCustomer_name(resultSet.getString(2));
				demandDraft.setIn_favor_of(resultSet.getString(3));
				demandDraft.setPhone_number(resultSet.getString(4));
				demandDraft.setOrderDate(resultSet.getDate(5));
				demandDraft.setDd_amount(resultSet.getDouble(6));
				demandDraft.setDd_commission(resultSet.getDouble(7));
				demandDraft.setDd_description(resultSet.getString(8));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return demandDraft;
	}
	
}
