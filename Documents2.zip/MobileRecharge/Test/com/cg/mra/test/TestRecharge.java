package com.cg.mra.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.mra.Dao.AccountDaoImpl;
import com.cg.mra.Exception.mobileRechargeException;
import com.cg.mra.beans.Account;

public class TestRecharge {
	
	
	static Account ser;
	static AccountDaoImpl dao;
	
	@Test
	public void TestToGetrechargeAccount() throws mobileRechargeException
	{

		assertTrue(dao.rechargeAccount("102", "35"));


	}
	
	
	
	
	
	

}
