package com.capgemini.AppDate_168347.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.AppDate_168347.exception.AppointmentException;
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.util.DatabaseConnection;





public class DoctorAppointmentDao implements IDoctorAppointmentDao {

	Connection conn;
	
	private int generateAppointmentId() throws AppointmentException{
		String sql="SELECT seq_appointment_id.NEXTVAL FROM dual";
		conn = DatabaseConnection.getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery(sql);
			rst.next();
			return rst.getInt(1);
		} catch (SQLException e) {
			throw new AppointmentException("Problem in generating Appointment ID "+e.getMessage());
		}
	}
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws AppointmentException {
		
		String sql = "INSERT INTO doctor_appointment VALUES(?,?,?,?,?,?,?,?,?,?)";
		doctorAppointment.setAppointmentId(generateAppointmentId());
		
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1, doctorAppointment.getAppointmentId());
			pst.setString(2, doctorAppointment.getPatienceName());
			pst.setString(3, doctorAppointment.getPhoneNumber());
			pst.setDate(4, doctorAppointment.getDateOfAppointment());
			pst.setString(5, doctorAppointment.getEmail());
			pst.setInt(6, doctorAppointment.getAge());
			pst.setString(7, doctorAppointment.getGender());
			pst.setString(8, doctorAppointment.getProblemName());
			pst.setString(9, doctorAppointment.getDoctorName());
			pst.setString(10, doctorAppointment.getAppointmentStatus());
			pst.executeUpdate();
			
		} catch (SQLException e) {

			throw new AppointmentException("Problem in Appointment Details");
		}
		
		return doctorAppointment.getAppointmentId();
	}

	@Override
	public List<DoctorAppointment> getAppointmentDetails(int appointmentId) throws AppointmentException {
		List<DoctorAppointment> patientList = new ArrayList<DoctorAppointment>();
		String sql ="SELECT patient_name,appointment_status,doctor_name,date_of_appointment FROM DOCTOR_APPOINTMENT WHERE appointment_id = ?";
		conn = DatabaseConnection.getConnection();
		try {
			PreparedStatement st = conn.prepareStatement(sql);
			st.setInt(1, appointmentId);
			ResultSet rst = st.executeQuery(sql);
			
			while(rst.next()){
				DoctorAppointment list = new DoctorAppointment();
				list.setPatienceName(rst.getString("patient_name"));
				list.setAppointmentStatus(rst.getString("appointment_status"));
				list.setDoctorName(rst.getString("doctor_name"));
				list.setDateOfAppointment(rst.getDate("date_of_appointment"));
				patientList.add(list);
			}
		} catch (SQLException e) {
			throw new AppointmentException("Problem in Appoint Status");
		}
		
		return patientList;
	}

	
}
