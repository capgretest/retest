package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;

public class DemandDraftService implements IDemandDraftService{
		DemandDraftDAO dao=new DemandDraftDAO();
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws Exception {
		// TODO Auto-generated method stub
		return dao.addDemandDraftDetails(demandDraft);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		// TODO Auto-generated method stub
		return dao.getDemandDraftDetails(transactionId);
	}

	@Override
	public double ddcmo(double amount) {
			if(amount<=5000){
				amount=amount + 10;
			}else if(amount>=5001 && amount<=10000){
				amount=amount + 41;
			}else if(amount>=10001 && amount <=100000){
				amount=amount + 51;
			}else if(amount>=100001 && amount<=500000)
			{
				amount=amount + 306;
			}
			return amount;
	}

}
