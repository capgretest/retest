package com.cg.FlatRegistrationService;

import java.util.List;

import com.cg.beans.FlatRegistration;
import com.cg.realestateexception.FlatRegistrationException;


public interface FlatRegistrationService {

	public FlatRegistration registerFlat(FlatRegistration flat) throws FlatRegistrationException;
	public List<FlatRegistration> getAllOwnerId() throws FlatRegistrationException;
	


}