package com.cg.ttb.dao;

public class QueryMapper {
	public static final String RETRIVE_ALL_TRAINDETAILS_QUERY="SELECT trainid,traintype,fromstop,tostop,fare,availableseats,dateofjourney from traindetails";
	public static final String GENERATE_BOOKINGID_QUERY="SELECT BOOKING_ID_SEQ.NEXTVAL from DUAL";
	public static final String INSERT_ALL_BOOKING_DETAILS_QUERY="INSERT INTO BOOKINGDETAILS VALUES (?,?,?,?)";
}
