package com.capgemini.AppDate_168347.exception;

public class AppointmentException extends Exception {

	public AppointmentException(String s){
		super(s);
	}
}
