package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.Pizzaorder;

public class PizzaorderDAO implements IpizzaorderDAO{

	@Override
	public int placeOrder(Customer customer, Pizzaorder Pizza) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Pizzaorder getOrderDetails(int orderid) {
		// TODO Auto-generated method stub
		return null;
	}

}
