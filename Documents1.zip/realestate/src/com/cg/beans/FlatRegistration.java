package com.cg.beans;

public class FlatRegistration {
	private String flatRegNo;
	private String ownerId;
	private String flatType;
	private String flatArea;
	private String rentAmount;
	private String depositAmount;
	private String ownerName;
	public FlatRegistration(String flatRegNo, String ownerId, String flatType,
			String flatArea, String rentAmount, String depositAmount,
			String ownerName) {
		super();
		this.flatRegNo = flatRegNo;
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
		this.ownerName = ownerName;
	}
	public String getFlatRegNo() {
		return flatRegNo;
	}
	public void setFlatRegNo(String flatRegNo) {
		this.flatRegNo = flatRegNo;
	}
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public String getFlatType() {
		return flatType;
	}
	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}
	public String getFlatArea() {
		return flatArea;
	}
	public void setFlatArea(String flatArea) {
		this.flatArea = flatArea;
	}
	public String getRentAmount() {
		return rentAmount;
	}
	public void setRentAmount(String rentAmount) {
		this.rentAmount = rentAmount;
	}
	public String getDepositAmount() {
		return depositAmount;
	}
	public void setDepositAmount(String depositAmount) {
		this.depositAmount = depositAmount;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	@Override
	public String toString() {
		return "FlatRegistration [flatRegNo=" + flatRegNo + ", ownerId="
				+ ownerId + ", flatType=" + flatType + ", flatArea=" + flatArea
				+ ", rentAmount=" + rentAmount + ", depositAmount="
				+ depositAmount + ", ownerName=" + ownerName + "]";
	}
	
	
	
	
	
	
}
