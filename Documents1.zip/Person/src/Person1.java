
public class Person1 {
	String firstname;
	String lastname;
	char gender;
	public  Person1(){
	}
public Person1(String firstname,String lastname,char gender)
{
this.firstname="firstname";
this.lastname="lastname";
this.gender= "gender";
}
public setname
public static void main(String[] args) {
	
}
}
