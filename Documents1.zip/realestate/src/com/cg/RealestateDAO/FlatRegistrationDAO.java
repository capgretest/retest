package com.cg.RealestateDAO;

import java.util.List;

import com.cg.beans.FlatRegistration;
import com.cg.realestateexception.FlatRegistrationException;



public interface FlatRegistrationDAO {
	public List< FlatRegistration> getAllOwnerId() throws FlatRegistrationException;;
	public FlatRegistration registerFlat(FlatRegistration flat) throws FlatRegistrationException;
}

