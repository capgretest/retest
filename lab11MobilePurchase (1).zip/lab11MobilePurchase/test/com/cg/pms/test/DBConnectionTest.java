package com.cg.pms.test;

import java.sql.Connection;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.pms.Util.DatabaseConnection;
import com.cg.pms.dao.CustomerDaoImpl;

public class DBConnectionTest {
	static CustomerDaoImpl daotest;
	static Connection dbCon;

	@BeforeClass
	public static void initialise() {
		daotest = new CustomerDaoImpl();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DatabaseConnection Test Case----\n");
	}

	@Test
	public void test() throws Exception {
		Connection dbCon = DatabaseConnection.getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DatabaseConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daotest = null;
		dbCon = null;
	}

}
