package com.cg.mra.ui;

import java.util.Scanner;




import com.cg.mra.Exception.mobileRechargeException;
import com.cg.mra.Service.AccountService;
import com.cg.mra.Service.AccountServiceImpl;
import com.cg.mra.beans.Account;


public class MainUI {

	public static void main(String[] args) {




		do {
            System.out.println("*****************MENU************************");
            
			System.out.println("1.Account Balance Enquiry");

			System.out.println("2.Recharge Account");

			System.out.println("3.Exit");
			
			 System.out.println("*********************************************");

			System.out.println("Enter your option");

			AccountService ser = new AccountServiceImpl();

			Scanner scanner = new Scanner(System.in);

			int option = scanner.nextInt();

			scanner.nextLine();

			switch (option) {

			  // BALANCE ENQUIRY
			case 1:

				System.out.println("Enter Account ID ");

				String accountId = scanner.nextLine();

				if (ser.validateAccountId(accountId) == false) {

					System.err.println("Enter the positive Account Id");

					break;

				}

				Account account = null;

				try {

					account = ser.getAccountDetails(accountId);

				} catch (mobileRechargeException e) {

					System.err.println(e.getMessage());

					break;

				}

				double accountBalance = account.getAccountBalance();

				System.out.println("Your Current Balance is " + accountBalance);

				break;

				 // Utilising the Recharge Service
			case 2:

				System.out.println("Enter Account id");

				accountId = scanner.nextLine();

				if (ser.validateAccountId(accountId) == false) {

					System.err.println("Enter the positive Account Id");

					break;

				}

				System.out.println("Enter recharge Amount");

				double rechargeAmount = scanner.nextDouble();

				scanner.nextLine();

				if (ser.validateAmount(rechargeAmount) == false) {

					System.err.println("Enter the positive amount");

					break;

				}

				try {

					ser.rechargeAccount(accountId, rechargeAmount);

				} catch (mobileRechargeException e) {

					System.err.println(e.getMessage());

					break;

				}

				System.out.println("Your Account Recharged Successfully");
				//System.out.println("Your Current Balance is " + currentBalance);


				break;
   
				// getting out from service
			case 3:

				System.out.println("************THANK YOU FOR UTILISING OUR SERVICE.....!!!! **************");

				System.exit(0);

			default:

				System.err.println("Enter the correct option");

			}

		} while (true);

	}






}

