package itCalculation;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class EmployeeValidation {
	
	/*******************Validating PAN Details********************/
	
	public static boolean isValidatePan(String pan) throws EmployeeException
	{
		
		Pattern pat = Pattern.compile("[A-Z]{5}+[0-9]{5}");
		Matcher mat = pat.matcher(pan);
		
		if(mat.matches())
		{
			return true;
		}
		else
		{
			throw new EmployeeException("\n Enter the correct Pan No. \n");
		}
	
	}
	
	/**********************Validating Salary************************/
	
	public static boolean isValidateSalary(String sal) throws EmployeeException
	{

		Pattern pat = Pattern.compile("\\d{2,15}.?[0-9]{2}");
		Matcher mat = pat.matcher(sal);
		if( mat.matches())
		{
			return true;
		}
		else 
		{
			throw new EmployeeException("\n Enter valid salary along with decimal values \n");
		}
	}
	

}
