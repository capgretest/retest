package Harish;
import java.util.Scanner;
public class Person<Gend>{
	private String firstName;
	private String lastName;
	private Gend gender;

	//Scanner sc =new Scanner(System.in);
	public String getfirstName()
	{
		return firstName;
	}
	public String getlastName() 
	{
		return lastName;

	}
	public <Gend> Gend getgender(){
		return (Gend) gender;
	}
	public void setfistName(String firstName)
	{
		this.firstName = firstName;
	}
	public void setlastName(String lastName)
	{
		this.lastName = lastName;
	}
	public void setgender(Gend gender)
	{
		this.gender = gender;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
