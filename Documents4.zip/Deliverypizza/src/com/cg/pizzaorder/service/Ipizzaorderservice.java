package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.Pizzaorder;

public interface Ipizzaorderservice {
	public int placeOrder(Customer customer, Pizzaorder  Pizza);

	public Pizzaorder getOrderDetails(int orderid);
}
