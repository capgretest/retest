package com.capgemini.donorapplication.test;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.donorapplication.dao.DonorDaoImpl;
import com.capgemini.donorapplication.exception.DonorException;
import com.capgemini.donorapplication.util.DBConnection;

public class DBConnectionTest {
	public static Connection getConnection() {
		Connection conn=null;

		 try

		 {

		 FileReader fr=new FileReader("resources/dbconfig.properties");

		 Properties p=new Properties();

		 p.load(fr);

		 Class.forName(p.getProperty("driver"));

		 conn=DriverManager.getConnection(p.getProperty("url"),p.getProperty("un"),p.getProperty("password"));

		 System.out.println(conn);

		 }

		 catch(IOException |ClassNotFoundException|SQLException e)
		
		 {

		 e.printStackTrace();

		 }

		 return conn;

		}

		public static void main(String[] args) {
			getConnection();
		}

	}