package com.cg.pms.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.pms.beans.Mobiles;
import com.cg.pms.beans.PurchaseDetails;
import com.cg.pms.Exception.PurchaseException;

public interface ICustomerService {
	public int addPurchase(PurchaseDetails purchasedetails) throws PurchaseException;
	public boolean validatePurchaseDetails(PurchaseDetails purchasedetails) throws PurchaseException;
	public ArrayList<Mobiles> getMobiledetails() throws PurchaseException;
	public int deleteMobileDetails(int mobileid) throws SQLException, PurchaseException;
	public List<String> getMobiles(double price);
	public PurchaseDetails getPurchaseDetails(int purchaseid) throws SQLException;

}
