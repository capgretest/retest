package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.Pizzaorder;


public interface IpizzaorderDAO {
	public int placeOrder(Customer customer, Pizzaorder  Pizza);

	public Pizzaorder getOrderDetails(int orderid);
}

