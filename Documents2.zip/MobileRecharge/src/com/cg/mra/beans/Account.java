package com.cg.mra.beans;

public class Account {

	private String accountId;

	private String accountType;

	private String customerName;

	private double accountBalance;



	public String getAccountId() {

		return accountId;

	}



	public void setAccountId(String accountId) {

		this.accountId = accountId;

	}



	public String getAccountType() {

		return accountType;

	}



	public void setAccountType(String accountType) {

		this.accountType = accountType;

	}



	public String getCustomerName() {

		return customerName;

	}



	public void setCustomerName(String customerName) {

		this.customerName = customerName;

	}



	public double getAccountBalance() {

		return accountBalance;

	}



	public void setAccountBalance(double accountBalance) {

		this.accountBalance = accountBalance;

	}



	@Override

	public String toString() {

		return "Account [accountId=" + accountId + ", accountType=" + accountType + ", customerName=" + customerName

				+ ", accountBalance=" + accountBalance + "]";

	}




}
