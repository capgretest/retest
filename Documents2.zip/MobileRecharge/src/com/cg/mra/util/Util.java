package com.cg.mra.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.mra.Exception.mobileRechargeException;



public class Util {
	private static Connection conn=null ;

	public static Connection getConnection() throws mobileRechargeException{

		FileInputStream fis= null;
		try {
			fis = new FileInputStream("Resource/jdbc.properties");
			Properties prop =new Properties();
			prop.load(fis);
			String url=prop.getProperty("dburl");
			String driver=prop.getProperty("driver");
			String user=prop.getProperty("username");
			String password=prop.getProperty("password");
			if (conn == null) {
				Class.forName(driver);
				System.out.println("driver found");
				conn = DriverManager.getConnection(url,user,password);
				System.out.println("connection established");
			}
		} catch (ClassNotFoundException e) {
			throw new mobileRechargeException("Driver not found"+ e.getMessage());
		} catch (SQLException e) {
			throw new mobileRechargeException(
					"Problem in establishng connection" + e.getMessage());
		} catch (FileNotFoundException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}



		finally{
			if(fis!=null)
				try {
					fis.close();
				} catch (IOException e) {
					System.err.println(e.getMessage());
				}
		}

		return conn;
	}
	
}
