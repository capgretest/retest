package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.Pizzaorder;

public class Pizzaorderservice implements Ipizzaorderservice{

	public int placeOrder(Customer customer, Pizzaorder  Pizza) {
		return 0;
	}

	public Pizzaorder getOrderDetails(int orderid) {
		return null;
	}
	}

	


