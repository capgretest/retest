package com.cg.ttb.exception;

import java.io.PrintStream;
import java.io.PrintWriter;

public class TrainException extends Exception {

	public TrainException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TrainException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public TrainException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public TrainException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public TrainException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
